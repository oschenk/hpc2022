#include "stats.h"

namespace stats {
    unsigned long long flops_diff;
    unsigned long long flops_bc;
    unsigned long long flops_blas1;
    unsigned int iters_cg;
    unsigned int iters_newton;
    bool verbose_output;
} // namespace stats
